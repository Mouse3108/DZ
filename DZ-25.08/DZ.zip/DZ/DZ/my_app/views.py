from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.


def show_page1(request):
    return HttpResponse('Это страница 1')


def show_page2(request):
    return HttpResponse('Это страница 2')
